If something does not look right, restart the app. If it still does not look right you can let me know in the forums, the User Files thread, or better yet, Discord.

Follow the project with insta updates, patches, and funny update comments here: https://github.com/asherao/DCS-WABU

If you have any ideas you'd like to see in the app, let me know!
Have fun!

~Bailey
ED Forums: Bailey
Discord: Bailey#6230