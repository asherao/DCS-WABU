If something does not look right, restart the app. If it still does not look right you can let me know in the forums, the User Files thread, or better yet, Discord.

If you have any ideas you'd like to see in the app, let me know!
Have fun!

~Bailey
NOV2020
ED Forums: Bailey
Discord: Bailey#6230
Bailey's VoiceAttack Discord: https://discord.gg/PbYgC5e

If you are feeling charitable, please feel free to donate here: https://www.paypal.me/asherao
100% of all donations will go to modules to make even more free profiles and utilities for the community! (For example, the up and coming Kiowa and EuroFighter!...)

Check out my other projects on the ED User Files: https://www.digitalcombatsimulator.com/en/files/?PER_PAGE=100&CREATED_BY=asherao

v1
-Released
v1.8.2
-Added stuff
-Fixed stuff
v2
-Added F-16C
-Added version notes
v2.1
-Added DCS v2.5.45915 F18C weapons and tpod 
v3.0 (DCS v2.5.6.57530)
-Updated F-16C
-Updated F-18C
-Updated A-10C (A-10C2)