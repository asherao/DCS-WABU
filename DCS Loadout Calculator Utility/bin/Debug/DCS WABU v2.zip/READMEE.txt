If something does not look right, restart the app. If it still does not look right you can let me know in the forums, the User Files thread, or better yet, Discord.

If you have any ideas you'd like to see in the app, let me know!
Have fun!

~Bailey
14APR2020
ED Forums: Bailey
Discord PM: Bailey#6230
Bailey's VoiceAttack Discord: https://discord.gg/PbYgC5e

If you are feeling charitable, please feel free to donate here: https://www.paypal.me/asherao
100% of all donations will go to modules to make even more free profiles for the community! (For example, the up and coming Kiowa, SuperCarrier, and EuroFighter!...)

Check out my other projects by searching "Uploaded by" "asherao" on the ED User Files: https://www.digitalcombatsimulator.com/en/files/

v1
-Released
v1.8.2
-Added stuff
-Fixed stuff
v2
-Added F-16C
-Added version notes